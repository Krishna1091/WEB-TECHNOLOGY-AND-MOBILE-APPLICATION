/* ============================================================
   KRISHNA BANK — Complete Application Logic
   Vanilla JS | localStorage | Multi-user | Full Banking
   ============================================================ */

'use strict';

/* ── Detect current page ── */
const IS_DASHBOARD = window.location.pathname.includes('dashboard');
const IS_AUTH = !IS_DASHBOARD;

/* ============================================================
   STORAGE HELPERS
   ============================================================ */
const Store = {
  get:    (k)    => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } },
  set:    (k, v) => localStorage.setItem(k, JSON.stringify(v)),
  remove: (k)    => localStorage.removeItem(k),

  getUsers:       () => Store.get('nb_users') || {},
  setUsers:       (u) => Store.set('nb_users', u),
  getSession:     () => Store.get('nb_session'),
  setSession:     (u) => Store.set('nb_session', u),
  clearSession:   () => Store.remove('nb_session'),
  getTxHistory:   (uid) => Store.get(`nb_tx_${uid}`) || [],
  setTxHistory:   (uid, txs) => Store.set(`nb_tx_${uid}`, txs),
};

/* ============================================================
   UTILITY FUNCTIONS
   ============================================================ */

/** Format number as ₹ currency */
function formatCurrency(n) {
  return '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** Generate unique account number */
function generateAccountNumber() {
  const now   = Date.now().toString().slice(-6);
  const rand  = Math.floor(1000 + Math.random() * 9000);
  return `NB${now}${rand}`;
}

/** Get formatted date-time string */
function getDateTime() {
  return new Date().toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  });
}

/** Get greeting based on time */
function getGreeting() {
  const h = new Date().getHours();
  if (h < 12)  return 'Good morning';
  if (h < 17)  return 'Good afternoon';
  return 'Good evening';
}

/* ============================================================
   TOAST NOTIFICATIONS
   ============================================================ */
function showToast(title, msg, type = 'error') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const icons = { error: 'fa-circle-xmark', success: 'fa-circle-check', warning: 'fa-triangle-exclamation' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span class="toast-icon"><i class="fa-solid ${icons[type] || icons.error}"></i></span>
    <div class="toast-text">
      <div class="toast-title">${title}</div>
      <div class="toast-msg">${msg}</div>
    </div>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('removing');
    setTimeout(() => toast.remove(), 320);
  }, 3500);
}

/* ============================================================
   LOADING SCREEN
   ============================================================ */
function hideLoader() {
  const el = document.getElementById('loading-screen');
  if (el) {
    setTimeout(() => el.classList.add('hidden'), 1500);
  }
}

/* ============================================================
   AUTH PAGE LOGIC
   ============================================================ */
if (IS_AUTH) {
  document.addEventListener('DOMContentLoaded', () => {
    hideLoader();

    // If already logged in, redirect
    if (Store.getSession()) {
      window.location.href = 'dashboard.html';
      return;
    }

    // Enter key support
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const loginTab = document.querySelector('#form-login.active');
      const signupTab = document.querySelector('#form-signup.active');
      if (loginTab)  handleLogin();
      if (signupTab) handleSignup();
    });
  });
}

/** Switch between login/signup tabs */
function switchTab(tab) {
  document.querySelectorAll('.auth-tab').forEach(t => {
    t.classList.toggle('active', t.dataset.tab === tab);
  });
  document.querySelectorAll('.auth-form').forEach(f => {
    f.classList.toggle('active', f.id === `form-${tab}`);
  });
  clearAllErrors();
}

/** Toggle password visibility */
function togglePassword(inputId, btn) {
  const input = document.getElementById(inputId);
  const icon  = btn.querySelector('i');
  if (!input) return;
  if (input.type === 'password') {
    input.type = 'text';
    icon.className = 'fa-solid fa-eye-slash';
  } else {
    input.type = 'password';
    icon.className = 'fa-solid fa-eye';
  }
}

/** Show field error */
function showError(id, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('show');
  const span = el.querySelector('span');
  if (span) span.textContent = msg;
}

/** Clear all form errors */
function clearAllErrors() {
  document.querySelectorAll('.form-error').forEach(e => e.classList.remove('show'));
}

/** Add ripple to button */
function addRipple(btn) {
  btn.classList.remove('ripple');
  void btn.offsetWidth;
  btn.classList.add('ripple');
  setTimeout(() => btn.classList.remove('ripple'), 600);
}

/** Handle Login */
function handleLogin() {
  clearAllErrors();
  const username = document.getElementById('login-username')?.value.trim();
  const password = document.getElementById('login-password')?.value;
  let valid = true;

  if (!username) {
    showError('login-username-error', 'Username is required');
    valid = false;
  }
  if (!password) {
    showError('login-password-error', 'Password is required');
    valid = false;
  }
  if (!valid) return;

  const users = Store.getUsers();
  const user  = Object.values(users).find(u => u.username === username);

  if (!user) {
    showError('login-global-error', 'No account found with this username');
    return;
  }
  if (user.password !== password) {
    showError('login-global-error', 'Incorrect password. Please try again.');
    return;
  }

  Store.setSession(user.id);
  showToast('Welcome Back!', `Signing in as ${user.name}…`, 'success');

  // Show loading then redirect
  const loadScreen = document.getElementById('loading-screen');
  if (loadScreen) loadScreen.classList.remove('hidden');
  setTimeout(() => { window.location.href = 'dashboard.html'; }, 1000);
}

/** Handle Signup */
function handleSignup() {
  clearAllErrors();
  const name     = document.getElementById('signup-name')?.value.trim();
  const username = document.getElementById('signup-username')?.value.trim();
  const password = document.getElementById('signup-password')?.value;
  const confirm  = document.getElementById('signup-confirm')?.value;
  const deposit  = parseFloat(document.getElementById('signup-deposit')?.value) || 0;
  let valid = true;

  if (!name || name.length < 2) {
    showError('signup-name-error', 'Enter your full name (min 2 chars)');
    valid = false;
  }
  if (!username || username.length < 3) {
    showError('signup-username-error', 'Username must be at least 3 characters');
    valid = false;
  }
  if (password.length < 6) {
    showError('signup-password-error', 'Password must be at least 6 characters');
    valid = false;
  }
  if (password !== confirm) {
    showError('signup-confirm-error', 'Passwords do not match');
    valid = false;
  }
  if (deposit < 0) {
    showError('signup-deposit-error', 'Opening deposit cannot be negative');
    valid = false;
  }
  if (!valid) return;

  const users = Store.getUsers();
  const exists = Object.values(users).find(u => u.username === username);
  if (exists) {
    showError('signup-username-error', 'Username already taken — choose another');
    return;
  }

  // Create user
  const id = 'user_' + Date.now();
  const accountNumber = generateAccountNumber();
  const newUser = {
    id, name, username, password,
    accountNumber,
    balance: deposit,
    createdAt: getDateTime(),
  };

  users[id] = newUser;
  Store.setUsers(users);

  // Opening transaction if deposit > 0
  if (deposit > 0) {
    const tx = buildTransaction('credit', deposit, deposit, 'Opening Deposit', null);
    Store.setTxHistory(id, [tx]);
  }

  showToast('Account Created!', `Welcome, ${name}! Signing you in…`, 'success');
  Store.setSession(id);

  const loadScreen = document.getElementById('loading-screen');
  if (loadScreen) loadScreen.classList.remove('hidden');
  setTimeout(() => { window.location.href = 'dashboard.html'; }, 1000);
}

/* ============================================================
   DASHBOARD LOGIC
   ============================================================ */
if (IS_DASHBOARD) {
  let currentUser = null;

  document.addEventListener('DOMContentLoaded', () => {
    // Auth guard
    const sessionId = Store.getSession();
    if (!sessionId) {
      window.location.href = 'index.html';
      return;
    }

    const users = Store.getUsers();
    currentUser = users[sessionId];
    if (!currentUser) {
      Store.clearSession();
      window.location.href = 'index.html';
      return;
    }

    hideLoader();
    initDashboard();
    startClock();
  });

  /** Initialize all dashboard data */
  function initDashboard() {
    refreshUserData();
    renderDashboard();
    renderTransactionPage();
    updateBadge();
  }

  /** Refresh user from storage */
  function refreshUserData() {
    const users = Store.getUsers();
    currentUser = users[Store.getSession()];
  }

  /** Render dashboard overview */
  function renderDashboard() {
    refreshUserData();
    const u = currentUser;
    const txs = Store.getTxHistory(u.id);

    // Sidebar
    setEl('sb-user-name', u.name);
    setEl('sb-user-id', u.accountNumber);
    setEl('topbar-section-name', 'Dashboard');

    // Greeting
    const hour = new Date().getHours();
    setEl('dash-greeting', `${getGreeting()}, ${u.name.split(' ')[0]} — here's your financial summary`);

    // Stat Cards with animated counters
    animateCounter('stat-balance', u.balance, true);
    const credits = txs.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0);
    const debits  = txs.filter(t => t.type !== 'credit').reduce((s, t) => s + t.amount, 0);
    animateCounter('stat-credits', credits, true);
    animateCounter('stat-debits',  debits,  true);
    setEl('stat-tx-count', txs.length);
    setEl('stat-credit-count', `${txs.filter(t => t.type === 'credit').length} transactions`);
    setEl('stat-debit-count',  `${txs.filter(t => t.type !== 'credit').length} transactions`);

    // Account card
    const formatted = u.accountNumber.match(/.{1,4}/g)?.join(' — ') || u.accountNumber;
    setEl('dash-account-number', formatted);
    setEl('dash-balance-display', Number(u.balance).toLocaleString('en-IN', { minimumFractionDigits: 2 }));
    setEl('dash-account-holder', u.name.toUpperCase());

    // Balance bar (max 200k = 100%)
    const pct = Math.min((u.balance / 200000) * 100, 100);
    setTimeout(() => {
      const bar = document.getElementById('balance-bar-fill');
      if (bar) bar.style.width = pct + '%';
    }, 300);

    // Recent transactions (last 5)
    renderRecentTx(txs.slice(-5).reverse());

    // Profile section
    setEl('profile-name', u.name);
    setEl('profile-username', '@' + u.username);
    setEl('profile-account', u.accountNumber);
    setEl('profile-since', u.createdAt);
    setEl('profile-balance', formatCurrency(u.balance));
    setEl('profile-tx-count', txs.length);
    setTimeout(() => {
      const bar = document.getElementById('profile-bar');
      if (bar) bar.style.width = pct + '%';
    }, 400);

    // Update withdraw modal balance
    setEl('modal-balance-display', formatCurrency(u.balance));
  }

  /** Render transactions overview */
  function renderTransactionPage() {
    refreshUserData();
    const u = currentUser;
    const txs = Store.getTxHistory(u.id);
    const now = new Date();

    const monthTxs = txs.filter(t => {
      const d = new Date(t.rawDate);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    });

    const monthIn  = monthTxs.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0);
    const monthOut = monthTxs.filter(t => t.type !== 'credit').reduce((s, t) => s + t.amount, 0);
    const monthNet = monthIn - monthOut;

    setEl('month-in',  formatCurrency(monthIn));
    setEl('month-out', formatCurrency(monthOut));
    const netEl = document.getElementById('month-net');
    if (netEl) {
      netEl.textContent = formatCurrency(Math.abs(monthNet));
      netEl.style.color = monthNet >= 0 ? 'var(--success)' : 'var(--red)';
    }
  }

  /** Render recent transactions (mini list) */
  function renderRecentTx(txs) {
    const container = document.getElementById('recent-tx-list');
    if (!container) return;

    if (!txs.length) {
      container.innerHTML = `<div class="tx-empty"><i class="fa-solid fa-receipt"></i><p>No transactions yet</p></div>`;
      return;
    }

    container.innerHTML = txs.map(tx => `
      <div class="mini-tx-item">
        <div class="mini-tx-icon ${tx.type}">
          <i class="fa-solid ${txTypeIcon(tx.type)}"></i>
        </div>
        <div class="mini-tx-info">
          <div class="mini-tx-type">${tx.description || tx.type}</div>
          <div class="mini-tx-date">${tx.date}</div>
        </div>
        <div class="mini-tx-amount ${tx.type}">
          ${tx.type === 'credit' ? '+' : '-'}${formatCurrency(tx.amount)}
        </div>
      </div>
    `).join('');
  }

  /** Render full transaction history table */
  function renderHistoryTable(filter = 'all') {
    refreshUserData();
    const u   = currentUser;
    const all = Store.getTxHistory(u.id);
    const txs = filter === 'all' ? all : all.filter(t => t.type === filter);
    const body = document.getElementById('tx-table-body');
    if (!body) return;

    if (!txs.length) {
      body.innerHTML = `<div class="tx-empty"><i class="fa-solid fa-inbox"></i><p>No ${filter === 'all' ? '' : filter + ' '}transactions found</p></div>`;
      return;
    }

    body.innerHTML = [...txs].reverse().map((tx, i) => `
      <div class="tx-row" style="animation-delay:${i * 0.04}s">
        <div class="tx-row-date">${tx.date}</div>
        <div>
          <div>${tx.description || txTypeLabel(tx.type)}</div>
          ${tx.to ? `<div class="tx-row-desc"><span class="tx-to">→ ${tx.to}</span></div>` : ''}
        </div>
        <div>
          <span class="tx-row-type ${tx.type}">
            <i class="fa-solid ${txTypeIcon(tx.type)}"></i>
            ${txTypeLabel(tx.type)}
          </span>
        </div>
        <div class="tx-row-amount ${tx.type}">
          ${tx.type === 'credit' ? '+' : '-'}${formatCurrency(tx.amount)}
        </div>
        <div class="tx-row-balance">${formatCurrency(tx.balance)}</div>
      </div>
    `).join('');
  }

  /** Filter transactions */
  function filterTransactions(filter, btn) {
    document.querySelectorAll('.tx-filter-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    renderHistoryTable(filter);
  }
  window.filterTransactions = filterTransactions;

  /** Update tx badge */
  function updateBadge() {
    const uid  = Store.getSession();
    const txs  = Store.getTxHistory(uid);
    const badge = document.getElementById('tx-count-badge');
    if (badge) badge.textContent = txs.length;
  }

  /* ── Navigation ── */
  function navigateTo(section) {
    // Hide all sections
    document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

    // Show target
    const target = document.getElementById(`section-${section}`);
    if (target) target.classList.add('active');
    const navItem = document.querySelector(`[data-section="${section}"]`);
    if (navItem) navItem.classList.add('active');

    // Section titles
    const titles = { dashboard: 'Dashboard', transactions: 'Transactions', history: 'History', profile: 'Profile' };
    setEl('topbar-section-name', titles[section] || section);

    // Lazy render
    if (section === 'history') renderHistoryTable('all');
    if (section === 'transactions') renderTransactionPage();
    if (section === 'dashboard') renderDashboard();
    if (section === 'profile') renderDashboard();

    closeSidebar();
  }
  window.navigateTo = navigateTo;

  /* ── Logout ── */
  function handleLogout() {
    Store.clearSession();
    showToast('Signed Out', 'You have been securely logged out', 'success');
    setTimeout(() => { window.location.href = 'index.html'; }, 800);
  }
  window.handleLogout = handleLogout;

  /* ── Sidebar ── */
  function toggleSidebar() {
    document.getElementById('sidebar')?.classList.toggle('open');
    document.getElementById('sidebar-overlay')?.classList.toggle('active');
  }
  function closeSidebar() {
    document.getElementById('sidebar')?.classList.remove('open');
    document.getElementById('sidebar-overlay')?.classList.remove('active');
  }
  window.toggleSidebar = toggleSidebar;
  window.closeSidebar = closeSidebar;

  /* ── Modals ── */
  function openModal(id) {
    const overlay = document.getElementById(id);
    if (!overlay) return;
    overlay.classList.add('active');

    // Reset modal fields and errors
    overlay.querySelectorAll('input').forEach(i => i.value = '');
    overlay.querySelectorAll('.form-error').forEach(e => e.classList.remove('show'));

    // Update balance display for withdraw
    if (id === 'modal-withdraw') {
      refreshUserData();
      setEl('modal-balance-display', formatCurrency(currentUser.balance));
    }

    // Reset transfer info
    if (id === 'modal-transfer') {
      const info = document.getElementById('transfer-recipient-info');
      if (info) info.style.display = 'none';
    }
  }
  function closeModal(id) {
    const overlay = document.getElementById(id);
    if (overlay) overlay.classList.remove('active');
  }
  window.openModal = openModal;
  window.closeModal = closeModal;

  // Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });

  // Transfer recipient lookup on input
  document.getElementById('transfer-to')?.addEventListener('input', function() {
    const val  = this.value.trim();
    const info = document.getElementById('transfer-recipient-info');
    const nameEl = document.getElementById('transfer-recipient-name');
    if (!info || !nameEl) return;

    if (val.length >= 6) {
      const users   = Store.getUsers();
      const recipient = Object.values(users).find(u =>
        u.accountNumber === val && u.id !== Store.getSession()
      );
      if (recipient) {
        info.style.display = 'block';
        nameEl.textContent = recipient.name;
      } else {
        info.style.display = 'none';
      }
    } else {
      info.style.display = 'none';
    }
  });

  /* ────────────────────────────────────────────────
     TRANSACTION PROCESSORS
  ──────────────────────────────────────────────── */

  /** Build a transaction record */
  function buildTransaction(type, amount, newBalance, description, to) {
    return {
      id: 'tx_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      type, amount, balance: newBalance,
      description: description || txTypeLabel(type),
      to: to || null,
      date: getDateTime(),
      rawDate: new Date().toISOString(),
    };
  }

  /** Save transaction for a user */
  function pushTransaction(uid, tx) {
    const txs = Store.getTxHistory(uid);
    txs.push(tx);
    Store.setTxHistory(uid, txs);
  }

  /** Update user balance */
  function updateBalance(uid, newBalance) {
    const users = Store.getUsers();
    users[uid].balance = newBalance;
    Store.setUsers(users);
    refreshUserData();
  }

  /** Process Deposit */
  function processDeposit() {
    const amountStr = document.getElementById('deposit-amount')?.value;
    const desc      = document.getElementById('deposit-desc')?.value.trim() || 'Deposit';
    clearFieldErrors('deposit-error');

    const amount = parseFloat(amountStr);
    if (!amount || amount <= 0) {
      showFieldError('deposit-error', 'Enter a valid deposit amount greater than 0');
      return;
    }
    if (amount > 10000000) {
      showFieldError('deposit-error', 'Maximum single deposit is ₹1,00,00,000');
      return;
    }

    const uid     = Store.getSession();
    const newBal  = currentUser.balance + amount;
    const tx      = buildTransaction('credit', amount, newBal, desc, null);

    updateBalance(uid, newBal);
    pushTransaction(uid, tx);

    closeModal('modal-deposit');
    showToast('Deposit Successful', `${formatCurrency(amount)} credited to your account`, 'success');
    renderDashboard();
    updateBadge();
  }
  window.processDeposit = processDeposit;

  /** Process Withdrawal */
  function processWithdraw() {
    const amountStr = document.getElementById('withdraw-amount')?.value;
    const desc      = document.getElementById('withdraw-desc')?.value.trim() || 'Withdrawal';
    clearFieldErrors('withdraw-error');

    const amount = parseFloat(amountStr);
    if (!amount || amount <= 0) {
      showFieldError('withdraw-error', 'Enter a valid withdrawal amount greater than 0');
      return;
    }
    if (amount > currentUser.balance) {
      showFieldError('withdraw-error', `Insufficient balance. Available: ${formatCurrency(currentUser.balance)}`);
      return;
    }

    const uid    = Store.getSession();
    const newBal = currentUser.balance - amount;
    const tx     = buildTransaction('debit', amount, newBal, desc, null);

    updateBalance(uid, newBal);
    pushTransaction(uid, tx);

    closeModal('modal-withdraw');
    showToast('Withdrawal Complete', `${formatCurrency(amount)} debited from your account`, 'success');
    renderDashboard();
    updateBadge();
  }
  window.processWithdraw = processWithdraw;

  /** Process Transfer */
  function processTransfer() {
    const toAccNo   = document.getElementById('transfer-to')?.value.trim();
    const amountStr = document.getElementById('transfer-amount')?.value;
    const desc      = document.getElementById('transfer-desc')?.value.trim() || 'Fund Transfer';
    clearFieldErrors('transfer-to-error');
    clearFieldErrors('transfer-amount-error');

    const amount = parseFloat(amountStr);

    if (!toAccNo) {
      showFieldError('transfer-to-error', 'Enter recipient account number');
      return;
    }

    const users     = Store.getUsers();
    const recipient = Object.values(users).find(u =>
      u.accountNumber === toAccNo && u.id !== Store.getSession()
    );

    if (!recipient) {
      showFieldError('transfer-to-error', 'Account not found. Verify the account number.');
      return;
    }
    if (toAccNo === currentUser.accountNumber) {
      showFieldError('transfer-to-error', 'Cannot transfer to your own account');
      return;
    }
    if (!amount || amount <= 0) {
      showFieldError('transfer-amount-error', 'Enter a valid transfer amount');
      return;
    }
    if (amount > currentUser.balance) {
      showFieldError('transfer-amount-error', `Insufficient balance. Available: ${formatCurrency(currentUser.balance)}`);
      return;
    }

    const senderUid = Store.getSession();
    const recvUid   = recipient.id;

    // Debit sender
    const senderNewBal = currentUser.balance - amount;
    const senderTx = buildTransaction('transfer', amount, senderNewBal, `Transfer to ${recipient.name}`, recipient.accountNumber);
    updateBalance(senderUid, senderNewBal);
    pushTransaction(senderUid, senderTx);

    // Credit recipient
    const recvNewBal = recipient.balance + amount;
    const recvTx = buildTransaction('credit', amount, recvNewBal, `Transfer from ${currentUser.name}`, currentUser.accountNumber);
    users[recvUid].balance = recvNewBal;
    Store.setUsers(users);
    pushTransaction(recvUid, recvTx);

    closeModal('modal-transfer');
    showToast('Transfer Sent', `${formatCurrency(amount)} sent to ${recipient.name}`, 'success');
    renderDashboard();
    updateBadge();
  }
  window.processTransfer = processTransfer;

  /* ── Clock ── */
  function startClock() {
    function update() {
      const el = document.getElementById('live-time');
      if (el) el.textContent = new Date().toLocaleTimeString('en-IN', { hour12: false });
    }
    update();
    setInterval(update, 1000);
  }
} // end IS_DASHBOARD

/* ============================================================
   SHARED HELPERS
   ============================================================ */

function setEl(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function showFieldError(id, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('show');
  const span = el.querySelector('span');
  if (span) span.textContent = msg;
}

function clearFieldErrors(...ids) {
  ids.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('show');
  });
}

function txTypeIcon(type) {
  const icons = { credit: 'fa-arrow-down', debit: 'fa-arrow-up', transfer: 'fa-right-left' };
  return icons[type] || 'fa-circle';
}

function txTypeLabel(type) {
  const labels = { credit: 'Credit', debit: 'Debit', transfer: 'Transfer' };
  return labels[type] || type;
}

/** Animate number counter */
function animateCounter(id, target, isCurrency) {
  const el = document.getElementById(id);
  if (!el) return;
  const duration = 1200;
  const step = 16;
  const steps = duration / step;
  let current = 0;
  const increment = target / steps;
  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      current = target;
      clearInterval(timer);
    }
    el.textContent = isCurrency
      ? '₹' + Number(current).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
      : Math.floor(current).toString();
  }, step);
}

/** Add button ripple on click */
document.addEventListener('click', (e) => {
  const btn = e.target.closest('.btn');
  if (!btn) return;
  const rect = btn.getBoundingClientRect();
  const ripple = document.createElement('span');
  ripple.style.cssText = `
    position:absolute;
    width:1px;height:1px;
    left:${e.clientX - rect.left}px;
    top:${e.clientY - rect.top}px;
    background:rgba(255,255,255,0.3);
    border-radius:50%;
    transform:scale(0);
    animation:btnRipple 0.5s ease-out forwards;
    pointer-events:none;
  `;
  if (!document.querySelector('#rippleStyle')) {
    const style = document.createElement('style');
    style.id = 'rippleStyle';
    style.textContent = `@keyframes btnRipple { to { transform:scale(200); opacity:0; } }`;
    document.head.appendChild(style);
  }
  btn.style.position = 'relative';
  btn.style.overflow = 'hidden';
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

/** Scroll reveal animations */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.stat-card, .dash-card, .tx-action-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  revealObserver.observe(el);
});
